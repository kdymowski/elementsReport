1. Names: Aidan Miller, Kyle Dymowski
2. Assisted by: N/A
3. Total time spent on project (both 10 and 11): ~20 hours
4. It is important to closely follow the API laid out by the book - straying from that may make code harder to debug.

In src dir run 

(i was able to copy paste this command)

javac Command.java Kind.java Parser.java SymbolTable.java TokenType.java Keyword.java Main.java Segment.java Tokenizer.java Writer.java

To Process folder run something similar to

java Main /home/curiosity-core/Elements/elementsReport/Project\ 11/Pong/
