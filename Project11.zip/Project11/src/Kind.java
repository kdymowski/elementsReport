public enum Kind {
	STATIC, FIELD, ARG, VAR, NONE
}
